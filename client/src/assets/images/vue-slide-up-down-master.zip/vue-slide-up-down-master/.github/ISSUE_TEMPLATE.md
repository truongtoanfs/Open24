If you want to report a bug, you ABSOLUTELY HAVE TO provide a link to a CodePen (from https://codepen.io/) with a reproduction of the bug, so that I can see the bug and fix the bug. It has to be CodePen. If you do not provide a link to a CodePen, I will close the issue.

If you want to report something else (mistakes in the docs, etc), you don't have to do anything special.
